# Class data — UGV facility scan

Data collected by the course UGV (AgileX Ranger Mini + RoboSense lidar + ZED X camera)
in a building corridor, 17–18 September 2026. Downsampled from the raw 440 MB capture
so it is quick to download in class.

| File | What it is | Size |
|---|---|---|
| `robot_trajectory.csv` | Robot position every ~0.1 s during a 10.5 min, 64 m lidar-SLAM run | 4,856 rows |
| `lidar_map.ply` | 3D lidar map built during that run (10 cm voxel grid) | 520k points |
| `facility_scan_color.ply` | Photo-colored 3D scan of the same area (ZED X + rtabmap, 5 cm voxel grid) | 660k points |
| `lidar_map_preview.png` | Top and side views of the lidar map | image |
| `facility_scan_preview.jpg` | Screenshot of the colored scan | image |
| `site_photo_corridor.jpg` | Photo of the scanned corridor | image |

## `robot_trajectory.csv` columns

| Column | Meaning |
|---|---|
| `timestamp` | Unix time in seconds |
| `t_s` | Seconds since the start of the run |
| `x_m`, `y_m`, `z_m` | Robot position in metres, in the map frame (start ≈ 0, 0, 0; z is up) |
| `qx`, `qy`, `qz`, `qw` | Orientation as a quaternion |

`robot_trajectory.csv` and `lidar_map.ply` share the same coordinate frame, so the path can be
drawn on top of the map. `facility_scan_color.ply` comes from a separate run with its own frame.

## Opening the point clouds

- Python: `open3d.io.read_point_cloud("data/lidar_map.ply")`
- Desktop viewers: [CloudCompare](https://www.cloudcompare.org) or [MeshLab](https://www.meshlab.net)
