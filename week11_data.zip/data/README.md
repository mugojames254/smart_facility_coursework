# Week 11 data — digital twin of a research institute

**Synthetic teaching data.** The building is real; the sensor readings and complaints are simulated.

| File | What it is |
|---|---|
| `building_twin.ifc` | BIM model (IFC4) of a 5-floor research institute: 82 rooms, walls, doors, windows, furniture. Based on the KIT *AC20-Institute-Var-2* sample model. For this class we added 2 air handling units (`IfcUnitaryEquipment` AHU-1, AHU-2), the rooms each one serves (`IfcZone`) and 253 room sensors (`IfcSensor`, each with an `SFM_Sensor` property set holding its `PointId`). |
| `rooms_ko.csv` | Our facility data per room: Korean name, use, floor, area, volume, facade, AHU. `room` = the IFC space number (`IfcSpace.Name`), `ifc_guid` = its GlobalId. |
| `sensors.csv` | The BMS point list: `point_id` (e.g. `AHU2.R203.ZN-T`), room, AHU, quantity, unit and the `ifc_guid` of the sensor or AHU in the IFC. |
| `readings.csv` | BMS export: one row per point every 15 min, 7–20 Sep 2026 (`timestamp, point_id, value`). About 350,000 rows. |
| `weather.csv` | Hourly outdoor weather in Suwon for the same two weeks (Open-Meteo historical data). |
| `complaints.csv` | 36 occupant complaints (KakaoTalk, web, phone) in Korean. `closed_at` is empty while a ticket is still open. |

## Floors

| IFC storey | Floor | Rooms |
|---|---|---|
| Keller | B1 | 001–017 |
| Erdgeschoss | 1F | 101–118 |
| 1. Obergeschoss | 2F | 201–222 |
| 2. Obergeschoss | 3F | 301–322 |
| Dachgeschoss | 4F | 401–403 |

AHU-1 (room 003) serves B1 and 1F. AHU-2 (room 004) serves 2F and 3F. The AHUs run on weekdays 07:00–21:00.

## Point names

`AHU2.R203.ZN-T` = AHU-2 zone, room 203, zone temperature. Suffixes: `ZN-T` temperature (°C), `ZN-RH` humidity (%RH), `ZN-CO2` CO2 (ppm), `ZN-OCC` people counted. AHU points: `SAT` supply air temperature, `RAT` return air temperature, `CHW-VLV` chilled-water valve command (%), `SF-STS` supply fan on/off.

## Credits

Building model: Karlsruhe Institute of Technology (KIT), Institute for Automation and Applied Informatics, *AC20-Institute-Var-2.ifc*. Weather: Open-Meteo.com historical weather API (CC BY 4.0).
