# Week 9 data: LLMs in Smart Facility Management

| File | What it is |
|---|---|
| `complaints_ko.csv` | 24 **synthetic** facility complaints (민원) in Korean, as they might arrive via KakaoTalk, web or phone. `true_category` and `true_priority` are the answers a facility team would give; use them to score the model. Phone numbers are fake. |
| `ahu2_manual_ko.pdf` | A 6-page **fictional** O&M manual for air handling unit AHU-2 (filters, belts, alarm codes, winter operation, safety). Written for teaching; not a real product. |
| `site_photo_corridor.jpg` | Real corridor photo from the Week 4 UGV run, for the vision-model inspection. |

Categories: plumbing, hvac, electrical, cleaning, safety, elevator, other.
Priorities: urgent, high, normal, low.
