# Final practical data — Smart Facility Management

| File | What it is | Used in |
|---|---|---|
| `complaints_final.csv` | 50 **synthetic** facility complaints (민원) in Korean. The `category` and `priority` columns are **empty**: your Python module fills them in with a local LLM. | Exercise 1 |
| `route_final.csv` | A **simulated** UGV inspection run (about 4 min), made on the real lidar map of the Week 4 building. Same columns as the Week 4 `robot_trajectory.csv`. | Exercise 2 |
| `lidar_map.ply` | The same lidar map of the building as in Week 4 (520k points). | Exercise 2 |

## `complaints_final.csv` columns

| Column | Meaning |
|---|---|
| `id` | Complaint ID, F01–F50 |
| `received` | Date and time the complaint arrived |
| `channel` | How it arrived: `kakao`, `web` or `phone` (`phone` = phone call) |
| `text` | The complaint as written. **This is the only column the LLM should read.** |
| `category` | Empty. Fill with one of: plumbing, hvac, electrical, cleaning, safety, elevator, other |
| `priority` | Empty. Fill with one of: urgent, high, normal, low |

One complaint (F49) contains a fake phone number in its text. Hide it before the text goes to the model, as in Week 9 (`mask_phone`).

Tip: read the file with `pd.read_csv("data/complaints_final.csv", dtype=str)`. Without `dtype=str`, pandas reads the empty columns as numbers and refuses to store words in them.

## `route_final.csv` columns

| Column | Meaning |
|---|---|
| `timestamp` | Unix time in seconds |
| `t_s` | Seconds since the start of the run |
| `x_m`, `y_m`, `z_m` | Robot position in metres, in the same frame as `lidar_map.ply` |
| `qx`, `qy`, `qz`, `qw` | Orientation as a quaternion (not needed for the exercise) |
